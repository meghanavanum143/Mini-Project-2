const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");

const app = express();

app.use(bodyParser.json());

// MongoDB Connection
mongoose.connect("mongodb://[Log in to view URL]:27017/studentDB", {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

// Student Schema
const studentSchema = new mongoose.Schema({
    name: String,
    rollNo: Number,
    department: String,
    age: Number
});

const Student = mongoose.model("Student", studentSchema);

// Create Student
app.post("/students", async (req, res) => {
    const student = new Student(req.body);
    await student.save();
    res.send(student);
});

// Get All Students
app.get("/students", async (req, res) => {
    const students = await Student.find();
    res.send(students);
});

// Get Student By ID
app.get("/students/:id", async (req, res) => {
    const student = await Student.findById(req.params.id);
    res.send(student);
});

// Update Student
app.put("/students/:id", async (req, res) => {
    const student = await Student.findByIdAndUpdate(
        req.params.id,
        req.body,
        { new: true }
    );
    res.send(student);
});

// Delete Student
app.delete("/students/:id", async (req, res) => {
    await Student.findByIdAndDelete(req.params.id);
    res.send("Student Deleted Successfully");
});

// Start Server
app.listen(3000, () => {
    console.log("Server running on port 3000");
});